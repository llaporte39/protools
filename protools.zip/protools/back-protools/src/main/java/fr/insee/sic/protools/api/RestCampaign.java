package fr.insee.sic.protools.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.Campaign;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.services.CampaignService;
import javassist.NotFoundException;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class RestCampaign {
	static final Logger LOGGER = LoggerFactory.getLogger(RestCampaign.class);

	@Autowired
	CampaignService campaignService;

	/* GET /campaigns : pour récupérer la liste des campagnes en cours */
	@GetMapping(value = "/campaigns", produces = "application/json")
	public Page<Campaign> afficherLesCampagnesEnCours(Pageable pageable) {
		LOGGER.info("Requete GET pour afficher toutes les campagnes");

		return campaignService.getCampagnesEnCours(pageable);
	}

	/* GET /campaigns : pour récupérer la liste des campagnes correspondant à un filtre */
	/*					 en fonction du nom court ou de l'identifiant  */
	@GetMapping(value = "/campaigns/{filtre}", produces = "application/json")
	public Page<Campaign> afficherCampaignsSelonFiltre(@PathVariable String filtre, Pageable pageable) {
		LOGGER.info("Requete GET pour la campagne avec le filtre: " + filtre);
		return campaignService.searchCampaignByIdCampaignWithFilter(
			 filtre, pageable);
	}
	
	/* GET /campaigns : pour récupérer une seule campagne selon son identifiant unique*/
	@GetMapping(value = "/campaigns/campaignByIdOperation/{idOperation}", produces = "application/json")
	public Page<Campaign> afficherCampaignSelonIdOperation(@PathVariable String idOperation, Pageable pageable) throws NotFoundException {
		LOGGER.info("Requete GET pour la campagne avec l'identifiant d'opération: " + idOperation);
		return campaignService.searchCampaignByIdOperationWithFilter(idOperation, pageable);
	}
	
	/* GET /campaigns : pour récupérer une seule campagne selon son identifiant unique*/
	@GetMapping(value = "/campaigns/campaign/{idCampaign}", produces = "application/json")
	public Campaign afficherCampaignSelonId(@PathVariable String idCampaign) throws NotFoundException {
		LOGGER.info("Requete GET pour la campagne avec l'identifiant: " + idCampaign);
		return campaignService.findById(idCampaign);
	}

	
	/* GET /campaigns : pour récupérer une seule campagne selon son identifiant unique*/
	@GetMapping(value = "/campaigns/campaign/{idOperation}", produces = "application/json")
	public Campaign afficherCampaignSelonIdOperation(@PathVariable String idCampaign) throws NotFoundException {
		LOGGER.info("Requete GET pour la campagne avec l'identifiant: " + idCampaign);
		return campaignService.findById(idCampaign);
	}

	/*
	 * POST /campaigns : créer une campagne avec un id donné. Vérifier la
	 * non préexistence de l'identifiant
	 */

	@PostMapping(value = "/campaigns", produces = "application/json")
	public Campaign ajouterUneCampaign(@RequestBody Campaign nouvelleCampaign) throws ResourceNotFoundException {
		LOGGER.info("Requete POST pour enregistrer une campagne");
		return campaignService.saveAndFlush(nouvelleCampaign);
	}

	
}
