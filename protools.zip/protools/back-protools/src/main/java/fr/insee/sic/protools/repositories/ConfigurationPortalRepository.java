package fr.insee.sic.protools.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.model.ConfigurationPortal;

@Service
public interface ConfigurationPortalRepository extends JpaRepository<ConfigurationPortal, String>{

	List<ConfigurationPortal> findAll();

	ConfigurationPortal findByIdConfigurationPortalContainingIgnoreCaseOrderByIdConfigurationPortalAsc(
			String filtre);

	ConfigurationPortal saveAndFlush(String idConfigurationPortal);

}
