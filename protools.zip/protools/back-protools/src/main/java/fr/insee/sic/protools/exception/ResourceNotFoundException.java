package fr.insee.sic.protools.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -2348059622111312475L;

	public ResourceNotFoundException(String ressource, String id) {
		super(String.format("Pas de '%s' pour la valeur : '%s'", ressource, id));
	}

}
