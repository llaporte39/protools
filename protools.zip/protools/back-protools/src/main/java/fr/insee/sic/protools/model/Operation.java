package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "operations")
public class Operation {

	@Id
	@Column (name = "id", nullable = false)	
	private String idOperation;

	@Column
	private String label;

	@Column
	private Date dateBeginCollect;

	@Column
	private Date dateEndCollect;

	@Column
    @JsonProperty(value="isOpen") 
	private boolean isOpen;

	@Column
    @JsonProperty(value="isCAPI") 
	private boolean isCAPI;

	@Column
    @JsonProperty(value="isCATI") 
	private boolean isCATI;

	@Column
    @JsonProperty(value="isCAWI") 
	private boolean isCAWI;

	@Column
    @JsonProperty(value="isPAPI") 
	private boolean isPAPI;

	public Operation() {
		super();
	}

	public Operation(String idOperation, String label, Date dateBeginCollect, Date dateEndCollect,
			boolean isOpen, boolean isCAPI, boolean isCAWI, boolean isPAPI, boolean isCATI) {
		super();
		this.idOperation = idOperation;
		this.label = label;
		this.dateBeginCollect = dateBeginCollect;
		this.dateEndCollect = dateEndCollect;
		this.isOpen = isOpen;
		this.isCAPI = isCAPI;
		this.isCAWI = isCAWI;
		this.isPAPI = isPAPI;
		this.isCATI = isCATI;
	}
	
	public String getIdOperation() {
		return idOperation;
	}

	public void setIdOperation(String idOperation) {
		this.idOperation = idOperation;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Date getDateBeginCollect() {
		return dateBeginCollect;
	}

	public void setDateBeginCollect(Date dateBeginCollect) {
		this.dateBeginCollect = dateBeginCollect;
	}

	public Date getDateEndCollect() {
		return dateEndCollect;
	}

	public void setDateEndCollect(Date dateEndCollect) {
		this.dateEndCollect = dateEndCollect;
	}

	@JsonProperty(value="isOpen") 
	public boolean isOpen() {
		return isOpen;
	}

	@JsonProperty(value="isOpen") 
	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
	}

	@JsonProperty(value="isCAPI") 
	public boolean isCAPI() {
		return isCAPI;
	}

	@JsonProperty(value="isCAPI") 
	public void setCAPI(boolean isCAPI) {
		this.isCAPI = isCAPI;
	}

	@JsonProperty(value="isCAWI") 
	public boolean isCAWI() {
		return isCAWI;
	}

	@JsonProperty(value="isCAWI") 
	public void setCAWI(boolean isCAWI) {
		this.isCAWI = isCAWI;
	}

	@JsonProperty(value="isPAPI") 
	public boolean isPAPI() {
		return isPAPI;
	}

	@JsonProperty(value="isPAPI") 
	public void setPAPI(boolean isPAPI) {
		this.isPAPI = isPAPI;
	}

	@JsonProperty(value="isCATI") 
	public boolean isCATI() {
		return isCATI;
	}

	@JsonProperty(value="isCATI") 
	public void setCATI(boolean isCATI) {
		this.isCATI = isCATI;
	}
	
}
