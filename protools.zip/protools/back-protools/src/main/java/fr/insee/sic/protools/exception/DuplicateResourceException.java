package fr.insee.sic.protools.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(value = HttpStatus.CONFLICT)
public class DuplicateResourceException extends RuntimeException {

	private static final long serialVersionUID = -2348059622111312475L;

	public DuplicateResourceException(String ressource, String id) {
		super(String.format("'%s' existe déjà pour les valeurs : '%s'", ressource, id));
	}

}
