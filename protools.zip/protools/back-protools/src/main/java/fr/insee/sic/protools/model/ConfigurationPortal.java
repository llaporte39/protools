package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.json.simple.JSONObject;


@Entity
@Table (name = "portals")
public class ConfigurationPortal {


	@Id
	@Column (name = "id", nullable = false)	
	private String idConfigurationPortal;

	private JSONObject contentPortal;
	
	private Date dateVersion;
	

	
	public ConfigurationPortal() {
		super();
	}

	public ConfigurationPortal(String idConfigurationPortal, JSONObject contentPortal, Date dateVersion) {
		super();
		this.idConfigurationPortal = idConfigurationPortal;
		this.contentPortal = contentPortal;
		this.dateVersion = dateVersion;
	}

	public String getIdConfigurationPortal() {
		return idConfigurationPortal;
	}

	public void setIdConfigurationPortal(String idConfigurationPortal) {
		this.idConfigurationPortal = idConfigurationPortal;
	}

	public JSONObject getContentPortal() {
		return contentPortal;
	}

	public void setContentPortal(JSONObject contentPortal) {
		this.contentPortal = contentPortal;
	}

	public Date getDateVersion() {
		return dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}
	

}
