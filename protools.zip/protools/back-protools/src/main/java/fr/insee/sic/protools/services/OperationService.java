package fr.insee.sic.protools.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.exception.DuplicateResourceException;
import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.repositories.OperationRepository;

@Service
public class OperationService {

	@Autowired
	OperationRepository operationRepo;

	public Page<Operation> getOperationsEnCours(Pageable pageable) {

		return operationRepo.findAll(pageable);
	}

	public Operation saveAndFlush(Operation operation) {
		String idOperation = operation.getIdOperation();

		if (!operationRepo.existsById(idOperation)) {
			return operationRepo.saveAndFlush(operation);
		} else {
			throw new DuplicateResourceException("L'opération ", idOperation);
		}
	}

	public Page<Operation> searchOperationByIdOperationWithFilter(String filtre, Pageable pageable) {
		return operationRepo.findByIdOperationContainingIgnoreCaseOrderByIdOperationAsc(filtre, pageable);
	}

	public Operation findById(String idOperation) throws ResourceNotFoundException {
		return operationRepo.findById(idOperation)
				.orElseThrow(() -> new ResourceNotFoundException("Opération ", idOperation));
	}

	public Operation updateOperation(String idOperation, Operation nouvelleOperation) {

		return operationRepo.findById(idOperation).map(op -> {

			op.setIdOperation(nouvelleOperation.getIdOperation());
			op.setLabel(nouvelleOperation.getLabel());
			op.setDateBeginCollect(nouvelleOperation.getDateBeginCollect());
			op.setDateEndCollect(nouvelleOperation.getDateEndCollect());
			op.setOpen(nouvelleOperation.isOpen());
			op.setCAPI(nouvelleOperation.isCAPI());
			op.setCAWI(nouvelleOperation.isCAWI());
			op.setPAPI(nouvelleOperation.isPAPI());
			op.setCATI(nouvelleOperation.isCATI());

			return operationRepo.save(op);
		}).orElseThrow(() -> new ResourceNotFoundException("Opération ", idOperation));
	}

	public void delete(String idOperation) {
		operationRepo.delete(findById(idOperation));
	}

}
