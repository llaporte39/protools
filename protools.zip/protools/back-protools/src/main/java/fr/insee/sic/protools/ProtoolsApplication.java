package fr.insee.sic.protools;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(scanBasePackages = "fr.insee.sic.protools")
@EnableSwagger2
public class ProtoolsApplication extends SpringBootServletInitializer {
	static final Logger LOGGER = LoggerFactory.getLogger(ProtoolsApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(ProtoolsApplication.class, args);
	}
	
	@RequestMapping (value = "/", method = RequestMethod.GET)
	public String helloWorld() {
		return "Hello World!";
	}
	
}
