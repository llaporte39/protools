package fr.insee.sic.protools.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.services.OperationService;
import javassist.NotFoundException;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class RestOperation {
	static final Logger LOGGER = LoggerFactory.getLogger(RestOperation.class);

	@Autowired
	OperationService operationService;

	/* GET /operations : pour récupérer la liste des opérations en cours */
	@GetMapping(value = "/operations", produces = "application/json")
	public Page<Operation> afficherLesOperationsEnCours(Pageable pageable) {
		LOGGER.info("Requete GET pour afficher toutes les opérations");
		
		return operationService.getOperationsEnCours(pageable);
	}
	
	/* GET /operations : pour récupérer la liste des opérations terminées */
	/*
	@GetMapping(value = "/operations")
	public JSONCollectionWrapper<Operation> afficherLesOperationsTerminées() {

		return new JSONCollectionWrapper<Operation>(operationService.getOperationsTerminées());
	}*/

	

	/* GET /operations : pour récupérer la liste des opérations correspondant à un filtre */
	/*					 en fonction du nom court ou de l'identifiant  */
	@GetMapping(value = "/operations/{filtre}", produces = "application/json")
	public Page<Operation> afficherOperationsSelonFiltre(@PathVariable String filtre, Pageable pageable) {
		LOGGER.info("Requete GET pour l'opération avec le filtre: " + filtre);
		return operationService.searchOperationByIdOperationWithFilter(
			 filtre, pageable);
	}
	
	/* GET /operations : pour récupérer une seule opération selon son identifiant unique*/
	@GetMapping(value = "/operations/operation/{idOperation}", produces = "application/json")
	public Operation afficherOperationSelonId(@PathVariable String idOperation) throws NotFoundException {
		LOGGER.info("Requete GET pour l'opération avec l'identifiant: " + idOperation);
		return operationService.findById(idOperation);
	}


	/*
	 * POST /operations : créer une operation avec un id d'operation donné. Vérifier la
	 * non préexistence de l'identifiant
	 */

	@PostMapping(value = "/operations", produces = "application/json")
	public Operation ajouterUneOperation(@RequestBody Operation nouvelleOperation) throws ResourceNotFoundException {
		LOGGER.info("Requete POST pour enregistrer une opération");
		return operationService.saveAndFlush(nouvelleOperation);
	}

	@PutMapping(value = "/operations/{idOperation}", produces = "application/json")
	public void mettreAJourUneOperation(@PathVariable String idOperation, @RequestBody Operation nouvelleOperation)
			 throws ResourceNotFoundException {
		LOGGER.info("Requete PUT pour mettre à jour l'opération " + idOperation);
		operationService.updateOperation(idOperation, nouvelleOperation);
	}	

	@DeleteMapping(value = "/operations/{idOperation}")
	public void supprimerUneOperation(@PathVariable String idOperation) {
		LOGGER.info("Requete DELETE pour supprimer une opération");
		operationService.delete(idOperation);

	}


}
