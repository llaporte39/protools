package fr.insee.sic.protools.services;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.exception.DuplicateResourceException;
import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.Campaign;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.repositories.CampaignRepository;

@Service
public class CampaignService {

	@Autowired
	CampaignRepository campaignRepo;

	public Page<Campaign> getCampagnesEnCours(Pageable pageable) {

		return campaignRepo.findAll(pageable);
	}

	public Page<Campaign> searchCampaignByIdCampaignWithFilter(String filtre, Pageable pageable) {
		return campaignRepo.findByIdCampaignContainingIgnoreCaseOrderByIdCampaignAsc(
				filtre, pageable);
	}

	public Page<Campaign> searchCampaignByIdOperationWithFilter(String filtre, Pageable pageable) {
		return campaignRepo.findByIdOperationIgnoreCaseOrderByIdOperationAsc(
				filtre, pageable);
	}

	public Campaign findById(String idCampaign) throws ResourceNotFoundException{
			return campaignRepo.findById(idCampaign)
							.orElseThrow(() -> new ResourceNotFoundException("Campaign ", idCampaign));
	}

	public Campaign saveAndFlush(Campaign nouvelleCampaign) {
		String idCampaign = nouvelleCampaign.getIdCampaign();

		if (!campaignRepo.existsById(idCampaign)) {
			return campaignRepo.saveAndFlush(nouvelleCampaign);
		} else {
			throw new DuplicateResourceException("La campagne ", idCampaign);
		}
	}
}
