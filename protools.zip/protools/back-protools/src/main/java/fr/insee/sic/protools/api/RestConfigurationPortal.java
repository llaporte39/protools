package fr.insee.sic.protools.api;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.ConfigurationPortal;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.repositories.ConfigurationPortalRepository;
import fr.insee.sic.protools.services.ConfigurationPortalService;

@RestController
public class RestConfigurationPortal {
	
	static final Logger LOGGER = LoggerFactory.getLogger(RestConfigurationPortal.class);

	@Autowired
	ConfigurationPortalService portalService;

	@Autowired
	ConfigurationPortalRepository portalRepo;

	/* GET /operations : pour récupérer la liste des Portals en cours */
	@GetMapping(value = "/portals", produces = "application/json")
	public List<ConfigurationPortal> showAllPortals() {
		LOGGER.info("Requete GET pour afficher tous les Portal");
		
		return portalService.getPortalsEnCours();
	}
	/*
	 * GET /operations : afficher un portal avec un id donné.
	 */
	@GetMapping(path = "/portals/{id}")
	public ResponseEntity<Object> showPortal(@PathVariable(value = "id") String id){
		LOGGER.info("Requête GET pour récupérer JSON Portal", id);
			Optional<ConfigurationPortal> configPortal = portalRepo.findById(id);
			if (!configPortal.isPresent()) {
				return new ResponseEntity<>(new JSONObject(), HttpStatus.OK);
			}else {
				return new ResponseEntity<>(configPortal.get(), HttpStatus.OK);
			}
		}
	
	/*
	 * POST /portal : créer un portal. Vérifier la
	 * non préexistence de l'identifiant
	 */

	@PostMapping(value = "/portals")
	public ConfigurationPortal addPortal(@RequestBody ConfigurationPortal nouveauPortal)
			throws ParseException, SQLException {

		return portalService.saveAndFlush(nouveauPortal);
			
		}
	/*
	 * GET /operations : updater un portal avec un id donné.
	 */
	@PutMapping(value = "/portals/{idConfigurationPortal}", produces = "application/json")
	public void updatePortal(@PathVariable String idConfigurationPortal, @RequestBody ConfigurationPortal nouveauPortal)
			 throws ResourceNotFoundException {
		LOGGER.info("Requete PUT pour mettre à jour le portal de promotion  " + idConfigurationPortal);
		portalService.updatePortal(idConfigurationPortal, nouveauPortal);
	}

	/*
	 * DELETE /operations : supprimer un portal avec un id donné.
	 */
	@DeleteMapping(value = "/portals/{idConfigurationPortal}")
	public void deletePortal(@PathVariable String idConfigurationPortal) {
		LOGGER.info("Requete DELETE pour supprimer un portal de promotion");
		portalService.delete(idConfigurationPortal);

	}



}
