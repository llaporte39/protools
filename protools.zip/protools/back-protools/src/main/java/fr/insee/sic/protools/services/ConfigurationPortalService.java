package fr.insee.sic.protools.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.exception.DuplicateResourceException;
import fr.insee.sic.protools.exception.ResourceNotFoundException;
import fr.insee.sic.protools.model.ConfigurationPortal;
import fr.insee.sic.protools.repositories.ConfigurationPortalRepository;

@Service
public class ConfigurationPortalService {

	@Autowired
	ConfigurationPortalRepository configurationPortalRepo;

	public ConfigurationPortal saveAndFlush(ConfigurationPortal configurationPortal) {
		String idConfigurationPortal = configurationPortal.getIdConfigurationPortal();

		if (!configurationPortalRepo.existsById(idConfigurationPortal)) {
			return configurationPortalRepo.saveAndFlush(configurationPortal);
		} else {
			throw new DuplicateResourceException("Le Portal ", idConfigurationPortal);
		}
	}

	public List<ConfigurationPortal> getPortalsEnCours() {
		
		return configurationPortalRepo.findAll();
	}

	public void updatePortal(String idConfigurationPortal, ConfigurationPortal nouveauPortal) {
		
			configurationPortalRepo.findById(idConfigurationPortal).map(portal -> {

				portal.setIdConfigurationPortal(nouveauPortal.getIdConfigurationPortal());
				portal.setContentPortal(nouveauPortal.getContentPortal());
				portal.setDateVersion(nouveauPortal.getDateVersion());
				
				return configurationPortalRepo.save(portal);
			}).orElseThrow(() -> new ResourceNotFoundException("Portal ", idConfigurationPortal));
		}

	public ConfigurationPortal findById(String idConfigurationPortal) throws ResourceNotFoundException{
			return configurationPortalRepo.findById(idConfigurationPortal)
							.orElseThrow(() -> new ResourceNotFoundException("Portal ", idConfigurationPortal));
	}
	
	public void delete(String idConfigurationPortal) {
		configurationPortalRepo.delete(findById(idConfigurationPortal));
	}


}
