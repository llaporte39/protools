package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "gestionOperation")
public class GestionOperation {

	@Id
	@Column (name = "id", nullable = false)	
	private String idOperationGestion;

	@Column
	private String label;

	@Column
	private Date collectLaunchDate;

	@Column
	private Date collectEndDate;

	@Column
	private Date surveyApertureDate;

	@Column
	private Date surveyClosureDate;

	@Column
	private String operationDescription;

	@Column
	private String operationResults;
	
	@Column
	private String keycloakConfig;

	public GestionOperation(String idOperationGestion, String label, Date collectLaunchDate, Date collectEndDate,
			Date surveyApertureDate, Date surveyClosureDate, String operationDescription, String operationResults,
			String keycloakConfig) {
		super();
		this.idOperationGestion = idOperationGestion;
		this.label = label;
		this.collectLaunchDate = collectLaunchDate;
		this.collectEndDate = collectEndDate;
		this.surveyApertureDate = surveyApertureDate;
		this.surveyClosureDate = surveyClosureDate;
		this.operationDescription = operationDescription;
		this.operationResults = operationResults;
		this.keycloakConfig = keycloakConfig;
	}

	public String getIdOperationGestion() {
		return idOperationGestion;
	}

	public void setIdOperationGestion(String idOperationGestion) {
		this.idOperationGestion = idOperationGestion;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Date getCollectLaunchDate() {
		return collectLaunchDate;
	}

	public void setCollectLaunchDate(Date collectLaunchDate) {
		this.collectLaunchDate = collectLaunchDate;
	}

	public Date getCollectEndDate() {
		return collectEndDate;
	}

	public void setCollectEndDate(Date collectEndDate) {
		this.collectEndDate = collectEndDate;
	}

	public Date getSurveyApertureDate() {
		return surveyApertureDate;
	}

	public void setSurveyApertureDate(Date surveyApertureDate) {
		this.surveyApertureDate = surveyApertureDate;
	}

	public Date getSurveyClosureDate() {
		return surveyClosureDate;
	}

	public void setSurveyClosureDate(Date surveyClosureDate) {
		this.surveyClosureDate = surveyClosureDate;
	}

	public String getOperationDescription() {
		return operationDescription;
	}

	public void setOperationDescription(String operationDescription) {
		this.operationDescription = operationDescription;
	}

	public String getOperationResults() {
		return operationResults;
	}

	public void setOperationResults(String operationResults) {
		this.operationResults = operationResults;
	}

	public String getKeycloakConfig() {
		return keycloakConfig;
	}

	public void setKeycloakConfig(String keycloakConfig) {
		this.keycloakConfig = keycloakConfig;
	}
	
	
}
