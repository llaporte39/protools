package fr.insee.sic.protools.configuration;

import java.util.Collection;

public class JSONCollectionWrapper<T> {
	private Collection<T> donnees;

	public Collection<T> getDonnees() {
		return donnees;
	}

	public void setDonnees(Collection<T> donnees) {
		this.donnees = donnees;
	}

	public JSONCollectionWrapper(Collection<T> donnees) {
		super();
		this.donnees = donnees;
	}

}
