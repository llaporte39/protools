package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "gestionCampaign")
public class GestionCampaign {

	@Id
	@Column (name = "id", nullable = false)	
	private String idGestionCampaign;

	@Column
	private Date dateOfficialLaunch;

	@Column
	private Date dateOfficialEnd;

	@Column
	private Date dateLettreAvis;

	@Column
	private Date dateMailAvis;

	@Column
	private Date datePortalLaunch;

	@Column
	private Date datePortalClosure;
	
	@Column
    @JsonProperty(value="isOpen") 
	private boolean isOpen;
	

	public GestionCampaign(String idGestionCampaign, Date dateOfficialLaunch, Date dateOfficialEnd, Date dateLettreAvis,
			Date dateMailAvis, Date datePortalLaunch, Date datePortalClosure, boolean isOpen) {
		super();
		this.idGestionCampaign = idGestionCampaign;
		this.dateOfficialLaunch = dateOfficialLaunch;
		this.dateOfficialEnd = dateOfficialEnd;
		this.dateLettreAvis = dateLettreAvis;
		this.dateMailAvis = dateMailAvis;
		this.datePortalLaunch = datePortalLaunch;
		this.datePortalClosure = datePortalClosure;
		this.isOpen = isOpen;
	}

	public String getIdGestionCampaign() {
		return idGestionCampaign;
	}

	public void setIdGestionCampaign(String idGestionCampaign) {
		this.idGestionCampaign = idGestionCampaign;
	}

	public Date getDateOfficialLaunch() {
		return dateOfficialLaunch;
	}

	public void setDateOfficialLaunch(Date dateOfficialLaunch) {
		this.dateOfficialLaunch = dateOfficialLaunch;
	}

	public Date getDateOfficialEnd() {
		return dateOfficialEnd;
	}

	public void setDateOfficialEnd(Date dateOfficialEnd) {
		this.dateOfficialEnd = dateOfficialEnd;
	}

	public Date getDateLettreAvis() {
		return dateLettreAvis;
	}

	public void setDateLettreAvis(Date dateLettreAvis) {
		this.dateLettreAvis = dateLettreAvis;
	}

	public Date getDateMailAvis() {
		return dateMailAvis;
	}

	public void setDateMailAvis(Date dateMailAvis) {
		this.dateMailAvis = dateMailAvis;
	}

	public Date getDatePortalLaunch() {
		return datePortalLaunch;
	}

	public void setDatePortalLaunch(Date datePortalLaunch) {
		this.datePortalLaunch = datePortalLaunch;
	}

	public Date getDatePortalClosure() {
		return datePortalClosure;
	}

	public void setDatePortalClosure(Date datePortalClosure) {
		this.datePortalClosure = datePortalClosure;
	}

	@JsonProperty(value="isOpen")
	public boolean isOpen() {
		return isOpen;
	}

	@JsonProperty(value="isOpen")
	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
	}
	
}
