package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "gestionCollectTool")
public class GestionCollectTool {

	@Id
	@Column (name = "id", nullable = false)	
	private String idGestionCollectTool;

	@Column
	private Date dateBeginCollect;

	@Column
	private Date dateEndCollect;

	@Column
	private Date dateFirstPostalRelaunch;

	@Column
	private Date dateFirstMailRelaunch;

	@Column
	private Date dateSecondPostalRelaunch;

	@Column
	private Date dateSecondMailRelaunch;

	@Column
	private Date dateThirdPostalRelaunch;

	@Column
	private Date dateThirdMailRelaunch;
	
	@Column
    @JsonProperty(value="isOpen") 
	private boolean isOpen;
	
	
	@Column
	private String collectAdvancementRate;
	
	public GestionCollectTool(String idGestionCollectTool, Date dateBeginCollect, Date dateEndCollect,
			Date dateFirstPostalRelaunch, Date dateFirstMailRelaunch, Date dateSecondPostalRelaunch,
			Date dateSecondMailRelaunch, Date dateThirdPostalRelaunch, Date dateThirdMailRelaunch, boolean isOpen,
			String collectAdvancementRate) {
		super();
		this.idGestionCollectTool = idGestionCollectTool;
		this.dateBeginCollect = dateBeginCollect;
		this.dateEndCollect = dateEndCollect;
		this.dateFirstPostalRelaunch = dateFirstPostalRelaunch;
		this.dateFirstMailRelaunch = dateFirstMailRelaunch;
		this.dateSecondPostalRelaunch = dateSecondPostalRelaunch;
		this.dateSecondMailRelaunch = dateSecondMailRelaunch;
		this.dateThirdPostalRelaunch = dateThirdPostalRelaunch;
		this.dateThirdMailRelaunch = dateThirdMailRelaunch;
		this.isOpen = isOpen;
		this.collectAdvancementRate = collectAdvancementRate;
	}
	
	public String getIdGestionCollectTool() {
		return idGestionCollectTool;
	}

	public void setIdGestionCollectTool(String idGestionCollectTool) {
		this.idGestionCollectTool = idGestionCollectTool;
	}

	public Date getDateBeginCollect() {
		return dateBeginCollect;
	}

	public void setDateBeginCollect(Date dateBeginCollect) {
		this.dateBeginCollect = dateBeginCollect;
	}

	public Date getDateEndCollect() {
		return dateEndCollect;
	}

	public void setDateEndCollect(Date dateEndCollect) {
		this.dateEndCollect = dateEndCollect;
	}

	public Date getDateFirstPostalRelaunch() {
		return dateFirstPostalRelaunch;
	}

	public void setDateFirstPostalRelaunch(Date dateFirstPostalRelaunch) {
		this.dateFirstPostalRelaunch = dateFirstPostalRelaunch;
	}

	public Date getDateFirstMailRelaunch() {
		return dateFirstMailRelaunch;
	}

	public void setDateFirstMailRelaunch(Date dateFirstMailRelaunch) {
		this.dateFirstMailRelaunch = dateFirstMailRelaunch;
	}

	public Date getDateSecondPostalRelaunch() {
		return dateSecondPostalRelaunch;
	}

	public void setDateSecondPostalRelaunch(Date dateSecondPostalRelaunch) {
		this.dateSecondPostalRelaunch = dateSecondPostalRelaunch;
	}

	public Date getDateSecondMailRelaunch() {
		return dateSecondMailRelaunch;
	}

	public void setDateSecondMailRelaunch(Date dateSecondMailRelaunch) {
		this.dateSecondMailRelaunch = dateSecondMailRelaunch;
	}

	public Date getDateThirdPostalRelaunch() {
		return dateThirdPostalRelaunch;
	}

	public void setDateThirdPostalRelaunch(Date dateThirdPostalRelaunch) {
		this.dateThirdPostalRelaunch = dateThirdPostalRelaunch;
	}

	public Date getDateThirdMailRelaunch() {
		return dateThirdMailRelaunch;
	}

	public void setDateThirdMailRelaunch(Date dateThirdMailRelaunch) {
		this.dateThirdMailRelaunch = dateThirdMailRelaunch;
	}

	@JsonProperty(value="isOpen")
	public boolean isOpen() {
		return isOpen;
	}

	@JsonProperty(value="isOpen")
	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
	}

	public String getCollectAdvancementRate() {
		return collectAdvancementRate;
	}

	public void setCollectAdvancementRate(String collectAdvancementRate) {
		this.collectAdvancementRate = collectAdvancementRate;
	}	
}
