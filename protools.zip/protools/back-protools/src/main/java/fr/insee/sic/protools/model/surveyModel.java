package fr.insee.sic.protools.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table (name = "surveyModel")
public class surveyModel {
	@Id
	@Column (name = "id", nullable = false)	
	private String idSurveyModel;

	@Column
	private String label;

	@Column
    @JsonProperty(value="isCAPI") 
	private boolean isCAPI;

	@Column
    @JsonProperty(value="isCATI") 
	private boolean isCATI;

	@Column
    @JsonProperty(value="isCAWI") 
	private boolean isCAWI;

	@Column
    @JsonProperty(value="isPAPI") 
	private boolean isPAPI;

	public surveyModel(String idSurveyModel, String label, boolean isCAPI, boolean isCATI, boolean isCAWI,
			boolean isPAPI) {
		super();
		this.idSurveyModel = idSurveyModel;
		this.label = label;
		this.isCAPI = isCAPI;
		this.isCATI = isCATI;
		this.isCAWI = isCAWI;
		this.isPAPI = isPAPI;
	}
	
	@JsonProperty(value="isCAPI") 
	public boolean isCAPI() {
		return isCAPI;
	}

	@JsonProperty(value="isCAPI") 
	public void setCAPI(boolean isCAPI) {
		this.isCAPI = isCAPI;
	}

	@JsonProperty(value="isCAWI") 
	public boolean isCAWI() {
		return isCAWI;
	}

	@JsonProperty(value="isCAWI") 
	public void setCAWI(boolean isCAWI) {
		this.isCAWI = isCAWI;
	}

	@JsonProperty(value="isPAPI") 
	public boolean isPAPI() {
		return isPAPI;
	}

	@JsonProperty(value="isPAPI") 
	public void setPAPI(boolean isPAPI) {
		this.isPAPI = isPAPI;
	}

	@JsonProperty(value="isCATI") 
	public boolean isCATI() {
		return isCATI;
	}

	@JsonProperty(value="isCATI") 
	public void setCATI(boolean isCATI) {
		this.isCATI = isCATI;
	}
	
}
