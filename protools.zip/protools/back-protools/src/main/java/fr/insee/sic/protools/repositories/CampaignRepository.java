package fr.insee.sic.protools.repositories;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.model.Campaign;
import fr.insee.sic.protools.model.Operation;

@Service
public interface CampaignRepository extends JpaRepository<Campaign, String>{

	Page<Campaign> findAll(Pageable pageable);

	Page<Campaign> findByIdCampaignContainingIgnoreCaseOrderByIdCampaignAsc(
			String filtre, Pageable pageable);
	
	Page<Campaign> findByIdOperationIgnoreCaseOrderByIdOperationAsc(
			String filtre, Pageable pageable);

}
