package fr.insee.sic.protools;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import fr.insee.sic.protools.model.Campaign;
import fr.insee.sic.protools.model.ConfigurationPortal;
import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.services.CampaignService;
import fr.insee.sic.protools.services.ConfigurationPortalService;
import fr.insee.sic.protools.services.OperationService;

@Component
public class DataLoader implements ApplicationRunner {
	
	static final Logger LOGGER = LoggerFactory.getLogger(DataLoader.class);

	@Autowired
	OperationService operationService;
	
	@Autowired
	ConfigurationPortalService portalService;
	
	@Autowired
	CampaignService campaignService;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		LOGGER.info("Pas de données en base - début du chargement des données de test");

		Operation nouvelleOperation;
		
		ConfigurationPortal nouveauPortal;
		
		Campaign nouvelleCampagne;
		
		JSONObject jsonContent = (JSONObject) new JSONObject();
		
		operationService.saveAndFlush(new Operation("idOperation", "label", new Date(), new Date(),
				false, true, true, true, true));
		nouvelleOperation = operationService.saveAndFlush(new Operation("fpe", "test", new Date(), new Date(),
				true, false, true, true, true));
		nouvelleOperation = operationService.saveAndFlush(new Operation("idOperation2", "label2", new Date(), new Date(),
				true, false, true, true, true));
		operationService.saveAndFlush(new Operation("idOperation3", "label3", new Date(), new Date(),
				true, true, false, true, true));
		operationService.saveAndFlush(new Operation("idOperation4", "label4", new Date(), new Date(),
				true, true, true, false, true));
		operationService.saveAndFlush(new Operation("idOperation5", "label5", new Date(), new Date(),
				true, true, true, true, false));
		operationService.saveAndFlush(new Operation("fpe Again", "fpe label", new Date(), new Date(),
				false, true, true, true, true));

		campaignService.saveAndFlush(new Campaign("FPE 2018", "FPE label", "FPE in english", new Date(), new Date(),
				"idOperation"));
		campaignService.saveAndFlush(new Campaign("idCampaign", "label Campagne", "label Campaign", new Date(), new Date(),
				"idOperation"));
		campaignService.saveAndFlush(new Campaign("idCampaign2", "label Campagne2", "label Campaign2", new Date(), new Date(),
				"fpe"));
		campaignService.saveAndFlush(new Campaign("idCampaign3", "label Campagne3", "label Campaign3", new Date(), new Date(),
				"idOperation2"));
		
		jsonContent.put("Texte", "ceci is the Content of the portal");
		
		portalService.saveAndFlush(new ConfigurationPortal("idOperation" , 
				jsonContent, new Date()));

		jsonContent.put("Champ Portal", "Portal numéro 1");

		portalService.saveAndFlush(new ConfigurationPortal("fpe", 
				jsonContent, new Date()));
		

		LOGGER.info("Données en base - Fin du chargement des données de test");
	}

}
