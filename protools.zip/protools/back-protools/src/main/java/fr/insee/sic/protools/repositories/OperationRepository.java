package fr.insee.sic.protools.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import fr.insee.sic.protools.model.Operation;

@Service
public interface OperationRepository extends JpaRepository<Operation, String>{

	Page<Operation> findAll(Pageable pageable);

	Page<Operation> findByIdOperationContainingIgnoreCaseOrderByIdOperationAsc(
			String filtre, Pageable pageable);

}
