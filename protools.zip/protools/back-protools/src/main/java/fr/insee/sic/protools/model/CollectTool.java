package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "collectTool")
public class CollectTool {

	@Id
	@Column (name = "id", nullable = false)	
	private String idCollectTool;

	@Column
	private String label;

	@Column
	private String vague;

	@Column
	private Date dateOfficialLaunch;

	@Column
	private Date dateOfficialEnd;

	@Column 
	private String modeCollect;
	
	public CollectTool() {
		super();
	}

	public CollectTool(String idCollectTool, String label, String vague, Date dateOfficialLaunch, Date dateOfficialEnd,
			String modeCollect) {
		super();
		this.idCollectTool = idCollectTool;
		this.label = label;
		this.vague = vague;
		this.dateOfficialLaunch = dateOfficialLaunch;
		this.dateOfficialEnd = dateOfficialEnd;
		this.modeCollect = modeCollect;
	}

	public String getIdCollectTool() {
		return idCollectTool;
	}

	public void setIdCollectTool(String idCollectTool) {
		this.idCollectTool = idCollectTool;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getVague() {
		return vague;
	}

	public void setVague(String vague) {
		this.vague = vague;
	}

	public Date getDateOfficialLaunch() {
		return dateOfficialLaunch;
	}

	public void setDateOfficialLaunch(Date dateOfficialLaunch) {
		this.dateOfficialLaunch = dateOfficialLaunch;
	}

	public Date getDateOfficialEnd() {
		return dateOfficialEnd;
	}

	public void setDateOfficialEnd(Date dateOfficialEnd) {
		this.dateOfficialEnd = dateOfficialEnd;
	}

	public String getModeCollect() {
		return modeCollect;
	}

	public void setModeCollect(String modeCollect) {
		this.modeCollect = modeCollect;
	}
	
}
