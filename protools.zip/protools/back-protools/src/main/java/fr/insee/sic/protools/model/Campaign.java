package fr.insee.sic.protools.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@Entity
@Table (name = "campaigns")
public class Campaign {

	@Id
	@Column (name = "id", nullable = false)	
	private String idCampaign;

	@Column
	private String label;

	@Column
	private String englishLabel;

	@Column
	private Date dateOfficialLaunch;

	@Column
	private Date dateOfficialEnd;
	
	@Column
	private String idOperation;
	
	public Campaign() {
		super();
	}

	public Campaign(String idCampaign, String label, String englishLabel, Date dateOfficialLaunch, Date dateOfficialEnd) {
		super();
		this.idCampaign = idCampaign;
		this.label = label;
		this.englishLabel = englishLabel;
		this.dateOfficialLaunch = dateOfficialLaunch;
		this.dateOfficialEnd = dateOfficialEnd;
	}

	public Campaign(String idCampaign, String label, String englishLabel, Date dateOfficialLaunch, Date dateOfficialEnd,
			String idOperation) {
		super();
		this.idCampaign = idCampaign;
		this.label = label;
		this.englishLabel = englishLabel;
		this.dateOfficialLaunch = dateOfficialLaunch;
		this.dateOfficialEnd = dateOfficialEnd;
		this.idOperation = idOperation;
	}

	public String getIdCampaign() {
		return idCampaign;
	}

	public void setIdCampaign(String idCampaign) {
		this.idCampaign = idCampaign;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getEnglishLabel() {
		return englishLabel;
	}

	public void setEnglishLabel(String englishLabel) {
		this.englishLabel = englishLabel;
	}

	public Date getDateOfficialLaunch() {
		return dateOfficialLaunch;
	}

	public void setDateOfficialLaunch(Date dateOfficialLaunch) {
		this.dateOfficialLaunch = dateOfficialLaunch;
	}

	public Date getDateOfficialEnd() {
		return dateOfficialEnd;
	}

	public void setDateOfficialEnd(Date dateOfficialEnd) {
		this.dateOfficialEnd = dateOfficialEnd;
	}

	public String getIdOperation() {
		return idOperation;
	}

	public void setIdOperation(String idOperation) {
		this.idOperation = idOperation;
	}
}
