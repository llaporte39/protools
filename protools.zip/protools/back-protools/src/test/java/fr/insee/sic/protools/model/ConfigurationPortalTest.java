package fr.insee.sic.protools.model;


import org.junit.Test;

public class ConfigurationPortalTest {
	@Test
	public void testConfigurationPortal() throws Exception {
		
	}

}
