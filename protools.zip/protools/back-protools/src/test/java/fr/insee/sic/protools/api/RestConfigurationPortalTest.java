package fr.insee.sic.protools.api;

public class RestConfigurationPortalTest {

}
