package fr.insee.sic.protools.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import fr.insee.sic.protools.ProtoolsApplication;

public class ProtoolsApplicationTest {

	@Test
	public void testHelloWorld() {
		ProtoolsApplication api = new ProtoolsApplication();

		// GIVEN
		assertEquals("Hello World!", api.helloWorld());
		// WHEN

		// THEN
	}
	

}
