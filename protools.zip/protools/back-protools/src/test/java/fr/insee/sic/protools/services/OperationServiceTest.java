package fr.insee.sic.protools.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import fr.insee.sic.protools.model.Operation;
import fr.insee.sic.protools.repositories.OperationRepository;
import fr.insee.sic.protools.services.OperationService;


@RunWith(MockitoJUnitRunner.class)
public class OperationServiceTest {

	@Mock
	private OperationRepository operationRepo;

	@InjectMocks
	private OperationService operationService;
	
	Pageable pageable;

	@Test
	public void testRecherche() throws Exception {
		List<Operation> operationDump =new ArrayList<>();
		Operation expected = (new Operation("idOperation", "label4", new Date(), new Date(),
				true, true, true, true, false));
		
		operationDump.add(operationService.saveAndFlush(new Operation("idBidon", "label1", new Date(), new Date(),
				true, true, true, true, false)));
		operationDump.add(new Operation("idBidon", "label2", new Date(), new Date(),
				true, true, true, true, false));
		operationDump.add(new Operation("idOperation", "label3", new Date(), new Date(),
				true, true, true, true, false));
		operationDump.add(new Operation("idOperation", "label4", new Date(), new Date(),
				true, true, true, true, false));
		operationDump.add(new Operation("idnomBidon", "label5", new Date(), new Date(),
				true, true, true, true, false));
		Mockito.when(operationService.searchOperationByIdOperationWithFilter("idOperation", pageable))
		.thenReturn(operationService.searchOperationByIdOperationWithFilter("idOperation", pageable));

		Page<Operation> operationTrouvee = operationService.searchOperationByIdOperationWithFilter("idOperation", pageable);
		Assert.assertEquals(expected, operationTrouvee);
	}
	
	

}
