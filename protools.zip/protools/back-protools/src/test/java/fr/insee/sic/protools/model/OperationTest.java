package fr.insee.sic.protools.model;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import fr.insee.sic.protools.model.Operation;

public class OperationTest {
	@Test
	public void testOperation() throws Exception {
		Operation operation=new Operation("idOperation", "label", new Date(), new Date(),
				true, true, true, true, false);
		assertEquals("idOperation",operation.getIdOperation());
		assertEquals(new Date(),operation.getDateBeginCollect());
		assertEquals(true,operation.isCAPI());
		assertEquals(false,operation.isCATI());
	}

}
