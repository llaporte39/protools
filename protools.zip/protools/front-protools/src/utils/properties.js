
/* Chemins */
    /* Chemin général */
    export const pathOperations = '/operations';
    export const pathCampaigns = '/campaigns';
    export const pathPortal = '/portals';
    
    /* Chemin vers la recherche d'une opération*/
    export const pathOperation = '/operation';
    /* Chemin vers la création d'une opération*/
    export const pathCreation = '/creation';
    /* Chemin vers la modification d'une opération*/
    export const pathModification = '/modification';