import axios from 'axios';
import { pathOperations} from '../utils/properties';

export default (urlBackEnd) => {
  let token = null;
  const myAxios = axios.create({
    baseURL: `${urlBackEnd}${pathOperations}/`,
  });

  myAxios.interceptors.request.use(async config =>
    Promise.resolve({
      ...config,
      headers: {
        ...config.headers,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json;charset=utf-8',
        Accept: 'application/json;charset=utf-8',
      },
    })
  );
  return myAxios;
};
