export { default } from './component';
