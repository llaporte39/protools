import React, { Component } from 'react';
import Header from '../header/component';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import PropTypes from 'prop-types';
import Enregistrement from '../enregistrement/component';
import Visualisation from '../visualisation/component';

const apiConfigPath = `${window.location.origin}/configuration.json`;

class Home extends Component {

  constructor() {
    super();
    this.state = {
      urlBackEnd: ''
    }
    fetch(apiConfigPath)
      .then(response => response.json())
      .then(data => {

        this.setState({
          urlBackEnd: data.urlBackEnd
        })
        console.log("urlDansJson :" + data.urlBackEnd)
      });
  }

  render() {
    const {urlBackEnd} = this.state;
    return urlBackEnd=='' ? <div>Loading ...</div> :
  
     (<>
      <Header />
      <Router>
        <div>

          {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
          <Switch>
            <Route path="/creation">
              <Enregistrement isCreation={true}
                isModification={false} urlBackEnd={urlBackEnd} />
            </Route>
            <Route path="/modification/:idOperation" >
              <Enregistrement isCreation={false}
                isModification={true} urlBackEnd={urlBackEnd} />
            </Route>
            <Route exact path="/" >
              <Visualisation urlBackEnd={urlBackEnd} />
            </Route>
            <Route path="*" component={NotFound} />
          </Switch>
        </div>
      </Router>
    </>
    );
  }
}


function Status({ code, children }) {
  return (
    <Route
      render={({ staticContext }) => {
        if (staticContext) staticContext.status = code;
        return children;
      }}
    />
  );
}

function NotFound() {
  return (
    <Status code={404}>
      <div>
        <h1>Sorry, can’t find that.</h1>
      </div>
    </Status>
  );
}

export default Home;
