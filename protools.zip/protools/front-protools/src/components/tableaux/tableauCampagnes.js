import React from 'react';
import dateFormat from 'dateformat';

export default function tableauOperation(props) {
  const { idCampaign,
    label,
    englishLabel,
    dateOfficialLaunch,
    dateOfficialEnd,
    idOperation } = props;


  return <tr id={idCampaign}>
  <td>{idCampaign}</td>
    <td>{label}</td>
    <td>{englishLabel}</td>
    <td>{dateFormat(dateOfficialLaunch, 'dd/mm/yyyy')}</td>
    <td>{dateFormat(dateOfficialEnd, 'dd/mm/yyyy')}</td>
    <td>{idOperation}</td>
  </tr>
}
