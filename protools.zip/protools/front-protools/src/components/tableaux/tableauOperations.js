import React from 'react';
import dateFormat from 'dateformat';
import { Link } from "react-router-dom";

export default function tableauOperation(props) {
  const { idOperation,
    label,
    dateBeginCollect,
    dateEndCollect,
    isOpen,
    isCAPI,
    isCAWI,
    isPAPI,
    isCATI } = props;


  return <tr id={idOperation}>
    <td>{idOperation}</td>
    <td>{label}</td>
    <td>{dateFormat(dateBeginCollect, 'dd/mm/yyyy')}</td>
    <td>{dateFormat(dateEndCollect, 'dd/mm/yyyy')}</td>
    <td>{isOpen ? "Ouvert" : "Fermé"}</td>
    <td>{isCAPI ? "oui" : "non"}</td>
    <td>{isCAWI ? "oui" : "non"}</td>
    <td>{isPAPI ? "oui" : "non"}</td>
    <td>{isCATI ? "oui" : "non"}</td>
    <td id="operations-buttons">

      <button
          type="button"
          className="btn btn-default glyphicon glyphicon-eye-open"
          title="Voir les campagnes" 
          onClick={() => props.onClickCampagneShow(idOperation)}/>
      

      <Link to={{
        pathname: `/modification/${idOperation}`,
      }}><button
          type="button"
          className="btn btn-default glyphicon glyphicon-pencil"
          title="Modifier" />
      </Link>

      <span id="little-space" />
      <span id="little-space" />
      <Link to="/">
        <button
          type="button"
          onClick={() => { if (window.confirm(`Voulez-vous supprimer cette opération?`)) props.onDeleteModalValidation(idOperation) }}
          className="btn btn-danger glyphicon glyphicon-trash"
          title="Supprimer" />

      </Link>
    </td>
  </tr>;
}
