import React, { Component } from 'react';
import { Link } from "react-router-dom";
import myAxios from '../../utils/api-call';
import '../../index.css';
import '../../grid.css';
import '../../switch.css';
import { pathOperations, pathOperation, pathPortal } from '../../utils/properties';

export default class Enregistrement extends Component {

    constructor(props) {
        super(props);
        this.state = {
            urlBackEnd : this.props.urlBackEnd,
            operationAModifier: null,
            idOperation: '',
            label: '',
            dateBeginCollect: '01/01/1900',
            dateEndCollect: '31/12/2099',
            isOpen: false,
            isCAPI: false,
            isCAWI: false,
            isPAPI: false,
            isCATI: false,
            formErrorComment: '',
            contentPortal: ''
        };
        this.handleChange = this.handleChange.bind(this);
        if (this.props.isModification) {
            this.state.idOperation = window.location.href.substring(window.location.href.lastIndexOf('/') + 1);

            myAxios()
                .get(`${this.state.urlBackEnd}${pathPortal}/${window.location.href.substring(window.location.href.lastIndexOf('/') + 1)}`)
                .then(res => {
                    this.setState({
                        idConfigurationPortal: res.data.idConfigurationPortal,
                        contentPortal: res.data.contentPortal,
                        dateVersion: res.data.dateVersion
                    });
                })
                .catch(error => {
                    console.log(error)
                });
        }
    }

    componentDidMount() {
        console.log(`iscreation : ${this.props.isCreation}`);
        console.log(`isModification : ${this.props.isModification}`);
        console.log(`urlBackEnd : ${this.props.urlBackEnd}`);
        const { idOperation } = this.state;
        
            this.props.isModification && myAxios()
                .get(`${this.state.urlBackEnd}${pathOperations}${pathOperation}/${idOperation}`)
                .then(res => {
                    this.setState({
                        idOperation: res.data.idOperation,
                        label: res.data.label,
                        dateBeginCollect: res.data.dateBeginCollect,
                        dateEndCollect: res.data.dateEndCollect,
                        isOpen: res.data.isOpen,
                        isCAPI: res.data.isCAPI,
                        isCAWI: res.data.isCAWI,
                        isPAPI: res.data.isPAPI,
                        isCATI: res.data.isCATI,
                        isModification: this.props.isModification
                    });
                })
                .catch(error => {
                    if (error.response.request.status !== 200)
                        this.setState({ formErrorComment: `Erreur de traitement` });
                });
    }

    handleChange(event) {
        const value =
            event.target.type === "checkbox" ? event.target.checked : event.target.value;
        this.setState({
            ...this.state,
            [event.target.name]: value
        });
    }

    onOpen = e => {
        this.setState({ isOpen: true });
    };

    onClose = e => {
        this.setState({ isOpen: false });
    };

    onValidateUpload(event) {
        var json;
        const { formErrorComment, contentPortal, idOperation } = this.state;
        var fichierUpload = event.target.files[0];
        var reader = new FileReader();
        reader.onload = (function (file) {
            return function (e) {
                try {
                    json = JSON.stringify(JSON.parse(e.target.result));
                    (contentPortal === undefined || contentPortal === '') &&
                        myAxios().post(`${this.state.urlBackEnd}${pathPortal}`, json)
                            .catch(error => {
                                if (error.response === undefined) {

                                } else {
                                    if (error.response.request.status === 409)
                                        this.setState({
                                            formErrorComment: `Problème d'identifiant`
                                        });
                                    alert(`Portal ${formErrorComment} créé.`);
                                }

                            });


                    contentPortal !== undefined && contentPortal !== '' &&
                        myAxios().put(`${this.state.urlBackEnd}${pathPortal}/${idOperation}`, json)
                            .catch(error => {
                                if (error.response.request.status === 409)
                                    this.setState({
                                        formErrorComment: `Problème d'identifiant`
                                    });
                                alert(`Portal ${formErrorComment} mis à jour1.`);
                            });


                } catch (error) {
                    alert('Erreur de traitement : ' + error);
                }
            }
        })(fichierUpload);
        reader.readAsText(fichierUpload);
    }

    onValidateDownload() {
        const { idOperation } = this.state;
        myAxios()
            .get(`${this.state.urlBackEnd}${pathPortal}/${idOperation}`)
            .then(res => {
                this.setState({
                    idConfigurationPortal: res.data.idConfigurationPortal,
                    contentPortal: res.data.contentPortal,
                    dateVersion: res.data.dateVersion,
                    data: res.data
                });
                this.exportToJson(this.state.data)
            })
            .catch(error => {
                console.log(error)
            });
    }

    exportToJson(objectData) {
        let filename = "export.json";
        let contentType = "application/json;charset=utf-8;";
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            var blob = new Blob([decodeURIComponent(encodeURI(JSON.stringify(objectData)))], { type: contentType });
            navigator.msSaveOrOpenBlob(blob, filename);
        } else {
            var a = document.createElement('a');
            a.download = filename;
            a.href = 'data:' + contentType + ',' + encodeURIComponent(JSON.stringify(objectData));
            a.target = '_blank';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
    }

    onValidateModalValidation() {
        const {
            idOperation,
            label,
            dateBeginCollect,
            dateEndCollect,
            isOpen,
            isCAPI,
            isCAWI,
            isPAPI,
            isCATI
        } = this.state;

        let operation = {
            idOperation,
            label,
            dateBeginCollect,
            dateEndCollect,
            isOpen,
            isCAPI,
            isCAWI,
            isPAPI,
            isCATI
        };
        if (this.verifyOperation(operation)) {

            if (this.props.isCreation) {
                this.ajouterOperation(operation);
            } else if (this.props.isModification) {
                console.log(`on lance modif`);
                this.modificationOperation(operation);
            }
        } else {
            console.log(`Opération invalide`);
        }
    }

    verifyOperation(operation) {
        const idOperation = operation.idOperation;
        const label = operation.label;
        const dateBeginCollect = operation.dateBeginCollect;
        const dateEndCollect = operation.dateEndCollect;
        var b = false;
        if (idOperation !== '' && label !== ''
            && dateBeginCollect !== '' && dateEndCollect !== '') {
            if (dateEndCollect >= dateBeginCollect) {
                b = true;
            } else {
                alert(`Problème: La date de début de collecte doit être antérieure à la date de fin de collecte`)
            }
        } else {
            alert(`Problème: Certains champs sont vides`)
        }
        return b;
    }


    ajouterOperation(operation) {
        const { formErrorComment } = this.state;
        myAxios().post(`${this.state.urlBackEnd}${pathOperations}`, operation)
            .catch(error => {
                if (error.response.request.status === 409)
                    this.setState({
                        formErrorComment: `Identifiant d'opération déjà existant`
                    });
                alert(`Opération ${operation.idOperation} déjà existante.`);
            });
        formErrorComment !== '' && alert(`Opération ${operation.idOperation} enregistrée.`);
    }

    modificationOperation(operation) {
        myAxios().put(`${this.state.urlBackEnd}${pathOperations}/${operation.idOperation}`, operation)
            .catch(error => {
                console.log(error);
            });
        alert(`Opération ${operation.idOperation} à modifier mise à jour.`);

    }





















    render() {
        const {
            isModification,
            label,
            formErrorComment,
            //contentPortal
        } = this.state;

        return (<>
            <div id="bloc-form" >
                <h3 className="title-enregistrement">
                    {isModification ? "Modification" : "Création"} d'une opération
                </h3>
                {formErrorComment === '' && <form >

                    <div className="grid-container" >
                        <div className="grid-column1" >
                            <div id="bloc-idOperation" >
                                <label >Identifiant : <span id="little-space" /></label>
                                <input type="text" id="champ-idOperation" name="idOperation" value={this.state.idOperation}
                                    disabled={isModification} placeholder="log-année-x00" onChange={this.handleChange} />

                            </div >
                            <div id="bloc-label" >
                                <label > Nom de l'opération : <span id="little-space" /></label>
                                <input type="text" id="champ-label" name="label" value={label} onChange={this.handleChange} />

                            </div >

                            <div id="groupe-bloc-dates" >
                                <div id="bloc-dateBeginCollect" >
                                    <label > Début de la collecte : </label><span id="little-space" />
                                    <input type="date" name="dateBeginCollect" className="form-control"
                                        value={this.state.dateBeginCollect.substring(0, 10)}
                                        onChange={this.handleChange} />
                                </div >
                                <div id="bloc-dateEndCollect" >
                                    <label> Fin de la collecte : </label><span id="little-space" />
                                    <input type="date" name="dateEndCollect" className="form-control"
                                        value={this.state.dateEndCollect.substring(0, 10)}
                                        onChange={this.handleChange} />
                                </div >
                            </div >
                        </div >
                        <div className="grid-column2" >
                            <div className="bloc-modesCollectAndSwitchCollectStatus" >
                                <div id="bloc-modesCollect" >
                                    <label>
                                        Modes de collecte :</label><br />
                                    <span id="little-space" />
                                    <label>
                                        <span id="little-space" />
                                        <input id="switch"
                                            type="checkbox"
                                            name="isCAPI"
                                            value={this.state.isCAPI}
                                            checked={this.state.isCAPI}
                                            onChange={this.handleChange}
                                        />
                                        <span id="little-space" /> CAPI
                                        </label>
                                    <br />
                                    <label>
                                        <span id="little-space" />
                                        <input id="switch"
                                            type="checkbox"
                                            name="isCATI"
                                            value={this.state.isCATI}
                                            checked={this.state.isCATI}
                                            onChange={this.handleChange}
                                        />
                                        <span id="little-space" /> CATI
                                        </label>

                                    <br />
                                    <label>
                                        <span id="little-space" />
                                        <input id="switch"
                                            type="checkbox"
                                            name="isCAWI"
                                            value={this.state.isCAWI}
                                            checked={this.state.isCAWI}
                                            onChange={this.handleChange}
                                        />
                                        <span id="little-space" /> CAWI
                                        </label>
                                    <br />
                                    <label>
                                        <span id="little-space" />
                                        <input id="switch"
                                            type="checkbox"
                                            name="isPAPI"
                                            value={this.state.isPAPI}
                                            checked={this.state.isPAPI}
                                            onChange={this.handleChange}
                                        />
                                        <span id="little-space" /> PAPI
                                        </label>
                                </div>
                                <div id="bloc-switchCollectStatus" >
                                    <label> Opération : {this.state.isOpen ? "Ouverte" : "Fermée"}
                                    </label>
                                    <br />
                                    <button
                                        id="openButton"
                                        type="button"
                                        className="btn btn-primary"
                                        disabled={this.state.isOpen}
                                        onClick={this.onOpen}>
                                        {`Ouvrir`}
                                    </button>
                                    <span id="little-space" />
                                    <button
                                        id="closeButton"
                                        type="button"
                                        className="btn btn-primary"
                                        disabled={!this.state.isOpen}
                                        onClick={this.onClose}>
                                        {`Fermer`}
                                    </button>

                                </div>

                            </div >
                        </div >
                        <div className="grid-column3" >

                            <div id="bloc-uploadPortalPromotion" className="portal-promotion" >
                                <label> Uploader le Portail Promotion </label>
                                <br />
                                <input
                                    type="file"
                                    id="uploadPortalButton"
                                    className="btn btn-primary"
                                    accept=".json"
                                    onInput={event => this.onValidateUpload(event)}

                                />
                            </div>
                            <div id="bloc-downloadPortalPromotion" className="portal-promotion" >
                                <label> Télécharger le Portail Promotion </label>
                                <br />
                                {//isModification && contentPortal !== '' && contentPortal !== undefined && 
                                    <button
                                        id="downloadPortalButton"
                                        type="button"
                                        className="btn btn-primary"
                                        onClick={() => { this.onValidateDownload() }}>
                                        {`Télécharger`}
                                    </button>}
                                {//contentPortal !== '' && contentPortal !== undefined &&
                                    // <label id="bloc-ContentPortal" >
                                    // Contenu du Portal : <span id="little-space" />
                                    //  <input type="text" name="ContentPortal" value={contentPortal.Texte} onChange={this.handleChange} />
                                    //  </label>
                                }
                            </div>
                        </div>
                        <div className="grid-footer" >

                            <br />
                            <br />
                            <button
                                id="SaveButton"
                                type="button"
                                className="btn btn-primary"
                                onClick={() => { if (window.confirm(`Voulez-vous enregistrer cette opération?`)) this.onValidateModalValidation() }}>
                                {`Enregistrer`}
                            </button>
                            <span id="little-space" />
                            <span id="little-space" />
                            <Link to="/">
                                <button
                                    id="CancelButton"
                                    type="button"
                                    className="btn btn-secondary" >
                                    {`Retour`}
                                </button>
                            </Link>
                        </div >
                    </div >
                </form>
                }
                {formErrorComment !== '' && formErrorComment.split(';').map(str => (
                    <h4 style={{ color: 'red' }} key={str}>
                        {str}
                    </h4>
                ))
                }

                {formErrorComment !== '' && <Link to="/">
                    <button
                        id="CancelButton"
                        type="button"
                        className="btn btn-secondary" >
                        {`Retour`}
                    </button>
                </Link>}
            </div >
        </>

        )
    }
}