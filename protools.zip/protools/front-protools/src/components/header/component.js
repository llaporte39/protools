import React, { Component } from 'react';
import logo from '../../img/logo.png';

export default class Header extends Component {

  render() {

    return (

        <nav className="navbar navbar-inverse navbar-static-top">

          <div className="container-fluid" id="app-header">
            <span id="logo-header">
              <img src={logo} id="logo" alt={'button'} />
            </span>
            <span id="user-header">Loïc Laporte</span>
            <span id="title-header">Protools</span>
                
          </div>
        </nav >
      
        

    );
  }
}