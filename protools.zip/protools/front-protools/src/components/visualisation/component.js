import React, { Component } from 'react';
import { Link } from "react-router-dom";
import myAxios from '../../utils/api-call';
import { pathOperation, pathOperations, pathCampaigns } from '../../utils/properties';
import TableauOperations from '../tableaux/tableauOperations';
import TableauCampaigns from '../tableaux/tableauCampagnes';

export default class Visualisation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            urlBackEnd: this.props.urlBackEnd,
            recherche: '',
            listeOperations: [],
            listeCampaigns: [],
            operationChoisie : null,
            idOperationASupprimer: ''
        };
        this.onDeleteModalValidation = this.onDeleteModalValidation.bind(this);
        this.onClickCampagneShow = this.onClickCampagneShow.bind(this);
    }

    componentDidMount() {
        this.listOperations();
    }

    listOperations() {
        myAxios()
            .get(`${this.state.urlBackEnd}${pathOperations}`)
            .then(res => {
                this.setState({ listeOperations: res.data.content });
            })
            .catch(error => {
                console.log(error);
            });

    }

    handleChange(event) {
        this.setState({
            recherche: event.target.value
        });
        myAxios()
            .get(`${this.state.urlBackEnd}${pathOperations}/${event.target.value}`)
            .then(res => {
                this.setState({ listeOperations: res.data.content });
            })
            .catch(error => {
                console.log(error);
            });
    }

    onDeleteModalValidation(idOperation) {
        myAxios()
            .delete(`${this.state.urlBackEnd}${pathOperations}/${idOperation}`)
            .then(response => {
                this.listOperations();
            })
            .catch(error => {
                console.log(error);
            });
    }


    onClickCampagneShow(idOperation) { 
        myAxios()
        .get(`${this.state.urlBackEnd}${pathOperations}${pathOperation}/${idOperation}`)
        .then(res => {
            // on a pas un tableau d'une opération mais une opération, et listeOperations ne peut pas l'afficher
            console.log(`${this.state.urlBackEnd}${pathOperations}${pathOperation}/${idOperation}`)
            console.log(res.data.dateBeginCollect)
            this.setState({ operationChoisie: res.data });
    
        })
        .catch(error => {
            console.log(error);
        });
        myAxios()
            .get(`${this.state.urlBackEnd}${pathCampaigns}/campaignByIdOperation/${idOperation}`)
            .then(res => {
                this.setState({ listeCampaigns: res.data.content });
            })
            .catch(error => {
                console.log(error);
            });
    }

    render() {

        let { listeOperations, listeCampaigns } = this.state;
        return (<>
            <form className="form-inline">
                <input
                    className="form-control"
                    id="search"
                    type="text"
                    placeholder="Rechercher des opérations"
                    onChange={e => {
                        this.handleChange(e);
                    }}
                />
                <Link to="/creation">
                    <button
                        type="button"
                        className="btn btn-success">
                        {`Ajouter une opération`}
                    </button>
                </Link>
            </form>
            <h4 />

            <div>
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Identifiant</th>
                            <th>Nom</th>
                            <th>Début de la collecte</th>
                            <th>Fin de la collecte</th>
                            <th>État</th>
                            <th>CAPI</th>
                            <th>CAWI</th>
                            <th>PAPI</th>
                            <th>CATI</th>
                            <th>Options</th>
                        </tr>
                    </thead>
                    <tbody>

                        {listeOperations !== undefined && listeOperations.map(
                            ({ idOperation,
                                label,
                                dateBeginCollect,
                                dateEndCollect,
                                isOpen,
                                isCAPI,
                                isCAWI,
                                isPAPI,
                                isCATI }) => (
                                    <TableauOperations
                                        key={idOperation}
                                        idOperation={idOperation}
                                        label={label}
                                        dateBeginCollect={dateBeginCollect}
                                        dateEndCollect={dateEndCollect}
                                        isOpen={isOpen}
                                        isCAPI={isCAPI}
                                        isCAWI={isCAWI}
                                        isPAPI={isPAPI}
                                        isCATI = {isCATI}
                                        onDeleteModalValidation = {this.onDeleteModalValidation}
                                        onClickCampagneShow = {this.onClickCampagneShow} />
                                )
                        )}
                        
                    </tbody>
                </table>
                {listeCampaigns !== undefined && 
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Identifiant</th>
                            <th>Nom</th>
                            <th>Nom anglais</th>
                            <th>Début de la campagne</th>
                            <th>Fin de la campagne</th>
                            <th>Opération</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                       { listeCampaigns.map(
                            ({ idCampaign,
                                label,
                                englishLabel,
                                dateOfficialLaunch,
                                dateOfficialEnd,
                                idOperation}) => (
                                    <TableauCampaigns 
                                        key = {idCampaign}
                                        idCampaign = {idCampaign}
                                        label = {label}
                                        englishLabel = {englishLabel}
                                        dateOfficialLaunch = {dateOfficialLaunch}
                                        dateOfficialEnd = {dateOfficialEnd}
                                        idOperation = {idOperation}/>
                                )
                        )}
                    </tbody>
                </table>}
            </div>
        </>
        );
    }
}
