import React from 'react';
import './App.css';
import HomeComponent from './components/home';

function App() {
  return (
    <HomeComponent>

  </HomeComponent>
  );
}

export default App;
