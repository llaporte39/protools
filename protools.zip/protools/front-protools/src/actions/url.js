import { URL_BACK_END } from './constants/url';

export const saveUrlBackEnd = url => ({
  type: URL_BACK_END,
  payload: url,
});